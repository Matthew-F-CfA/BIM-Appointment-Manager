package bim.appointment;

import java.io.Serializable;
import java.util.Date;

class AppointmentObject
implements Serializable {
  String strName;
  Date dateDate;
  Integer intDurationHours;
  Integer intDurationMinutes;
  String strLocation;
  String strNotes="";
  EntityObject entObj[]=new EntityObject[0];

  AppointmentObject(String strName, Date dateDate, int intDurationHours, int intDurationMinutes, String strLocation, EntityObject entObj[]) {
    this.strName=strName;
    this.dateDate=dateDate;
    this.intDurationHours=new Integer(intDurationHours);
    this.intDurationMinutes=new Integer(intDurationMinutes);
    this.strLocation=strLocation;
    this.entObj=entObj;
  }

  public String getName() {
    return strName;
  }

  public void setName(String strName) {
    this.strName=strName;
  }

  public Date getDate() {
    return dateDate;
  }

  public void setDate(Date dateDate) {
    this.dateDate=dateDate;
  }

  public int getDurationHours() {
    return intDurationHours.intValue();
  }

  public void setDurationHours(int intDurationHours) {
    this.intDurationHours=new Integer(intDurationHours);
  }

  public int getDurationMinutes() {
    return intDurationMinutes.intValue();
  }

  public void setDurationMinutes(int intDurationMinutes) {
    this.intDurationMinutes=new Integer(intDurationMinutes);
  }

  public String getLocation() {
    return strLocation;
  }

  public void setLocation(String strLocation) {
    this.strLocation=strLocation;
  }

  public String getNotes() {
    return strNotes;
  }

  public void setNotes(String strNotes) {
    this.strNotes=strNotes;
  }

  public EntityObject[] getEntities() {
    return entObj;
  }

  public void setEntities(EntityObject entObj[]) {
    this.entObj=entObj;
  }
}
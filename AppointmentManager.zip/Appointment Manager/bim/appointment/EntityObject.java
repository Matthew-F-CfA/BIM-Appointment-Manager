package bim.appointment;

import java.io.Serializable;
import java.util.Vector;

class EntityObject
implements Serializable {
  String strName;
  String strDescription="";
  Integer intRating=new Integer(0);
  Integer intRatingCount=new Integer(0);
  Double dblRatingReal=new Double(0.0d);
  String strNotes="";
  Vector vecAppointmentsMissed=new Vector();
  Vector vecAppointments=new Vector();

  EntityObject(String strName) {
    this.strName=strName;
  }

  EntityObject(String strName, String strDescription) {
    this.strName=strName;
    this.strDescription=strDescription;
  }

  public String getName() {
    return strName;
  }

  public void setName(String strName) {
    this.strName=strName;
  }

  public String getDescription() {
    return strDescription;
  }

  public void setDescription(String strDescription) {
    this.strDescription=strDescription;
  }

  public int getRating() {
    return intRating.intValue();
  }

  public void setRating(int intRating) {
    this.intRating=new Integer(intRating);
  }

  public int getRatingCount() {
    return intRatingCount.intValue();
  }

  public void  setRatingCount(int intRatingCount) {
    this.intRatingCount=new Integer(intRatingCount);
  }

  public double getRatingReal() {
    return dblRatingReal.doubleValue();
  }

  public void setRatingReal(double dblRatingReal) {
    this.dblRatingReal=new Double(dblRatingReal);
  }

  public String getNotes() {
    return strNotes;
  }

  public void setNotes(String strNotes) {
    this.strNotes=strNotes;
  }

  public Vector getAppointmentsMissed() {
    return vecAppointmentsMissed;
  }

  public void setAppointmentsMissed(Vector vecAppointmentsMissed) {
    this.vecAppointmentsMissed=vecAppointmentsMissed;
  }

  public Vector getAppointments() {
    return vecAppointments;
  }

  public void setAppointments(Vector vecAppointments) {
    this.vecAppointments=vecAppointments;
  }
}
package bim.appointment;

import java.awt.*;
import java.awt.event.*;

class ListDialog extends Dialog
implements ActionListener {
  List lstList;
  Button btnSelect=new Button("Select");
  Button btnCancel=new Button("Cancel");
  volatile boolean cancelIt=false;

  ListDialog(Frame parent, String strTitle, List lstList) {
    super(parent, strTitle, true);
    this.lstList=lstList;

    add("Center", lstList);

    Panel tempPan=new Panel();
    tempPan.add(btnSelect);
    btnSelect.addActionListener(this);
    tempPan.add(btnCancel);
    btnCancel.addActionListener(this);
    add("South", tempPan);

    Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(screenDim.width/4, screenDim.height/4);
    setSize(screenDim.width/2, screenDim.height/2);
  }

  public void actionPerformed(ActionEvent ae) {
   Object evSource=ae.getSource();

    if(evSource==btnSelect) {
      int intSelIndex=lstList.getSelectedIndex();
      if(intSelIndex==-1)
        return;

      cancelIt=false;
      dispose();
    }
    else if(evSource==btnCancel) {
      cancelIt=true;
      dispose();
    }
  }
}
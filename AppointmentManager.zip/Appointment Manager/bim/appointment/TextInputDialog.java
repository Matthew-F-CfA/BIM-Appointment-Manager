package bim.appointment;

import java.awt.*;
import java.awt.event.*;

class TextInputDialog extends Dialog
implements ActionListener {
  TextField txtInput=new TextField();
  Button btnInput=new Button("Input");
  Button btnCancel=new Button("Cancel");
  volatile boolean cancelIt=false;

  TextInputDialog(Frame parent, String strTitle, String strText, String strButton) {
    super(parent, strTitle, true);

    btnInput.setLabel(strButton);

    Panel tempPan=new Panel();
    tempPan.setLayout(new BorderLayout());
    tempPan.add("West", new Label(strText));
    tempPan.add("Center", txtInput);
    add("North", tempPan);

    add("Center", new Label(""));

    Panel tempPan2=new Panel();
    tempPan2.add(btnInput);
    btnInput.addActionListener(this);
    tempPan2.add(btnCancel);
    btnCancel.addActionListener(this);
    add("South", tempPan2);

    Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(screenDim.width/4, screenDim.height/4);
    setSize(screenDim.width/2, screenDim.height/2);
  }

  public String getInput() {
    return txtInput.getText();
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnInput) {
      cancelIt=false;
      dispose();
    }
    else if(evSource==btnCancel) {
      cancelIt=true;
      dispose();
    }
  }
}
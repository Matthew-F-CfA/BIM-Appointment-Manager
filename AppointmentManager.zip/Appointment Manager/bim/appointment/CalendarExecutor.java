package bim.appointment;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.JFileChooser;
import java.util.Date;
import java.util.Vector;
import java.util.Hashtable;
import java.util.TreeMap;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Arrays;
import java.util.Map;
import java.util.Iterator;
import java.io.*;

class CalendarExecutor extends Frame
implements ActionListener {
  Dimension screenDim;
  CalendarCanvas calCanvas=new CalendarCanvas();

  CalendarObject calObj;

  Hashtable hashEntities=new Hashtable();

  AppointmentViewerFrame appointmentViewerFrame=new AppointmentViewerFrame();

  EntityViewerFrame entityViewerFrame=new EntityViewerFrame();

  CalendarTimeSlotFrame calTimeSlotFrame=new CalendarTimeSlotFrame();

  String strCalendarFileName="";

  Menu menuFile=new Menu("File");
  MenuItem menuFileLoad=new MenuItem("Load Calendar");
  MenuItem menuFileSave=new MenuItem("Save Calendar");
  MenuItem menuFileExit=new MenuItem("Exit");

  Menu menuOptions=new Menu("Options");
  Menu menuOptionsCalendar=new Menu("Calendar");
  MenuItem menuOptionsCalendarSetYear=new MenuItem("Set Year");
  MenuItem menuOptionsCalendarSetMonth=new MenuItem("Set Month");
  Menu menuOptionsAppointment=new Menu("Appointment");
  MenuItem menuOptionsAppointmentView=new MenuItem("View");
  MenuItem menuOptionsAppointmentCalendar=new MenuItem("Calendar");
  MenuItem menuOptionsAppointmentSchedule=new MenuItem("Schedule");
  MenuItem menuOptionsAppointmentNew=new MenuItem("New");
  MenuItem menuOptionsAppointmentDelete=new MenuItem("Delete");
  Menu menuOptionsEntity=new Menu("Entity");
  MenuItem menuOptionsEntityView=new MenuItem("View");
  MenuItem menuOptionsEntityNew=new MenuItem("New");
  MenuItem menuOptionsEntityDelete=new MenuItem("Delete");

  public static void main(String args[]) {
    try {
      CalendarExecutor cFrame=new CalendarExecutor();
      cFrame.screenDim=Toolkit.getDefaultToolkit().getScreenSize();
      cFrame.setSize(cFrame.screenDim.width, cFrame.screenDim.height-40);
      cFrame.setVisible(true);

      cFrame.appointmentViewerFrame.setSize(cFrame.screenDim.width, cFrame.screenDim.height-40);
      cFrame.entityViewerFrame.setSize(cFrame.screenDim.width, cFrame.screenDim.height-40);
      cFrame.calTimeSlotFrame.setSize(cFrame.screenDim.width, cFrame.screenDim.height-40);

      cFrame.calObj=new CalendarObject();

/*
      File fileCalendar=new File("CalendarObject");
      if(fileCalendar.exists()) {
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileCalendar));
        cFrame.calObj=(CalendarObject)ois.readObject();
        ois.close();
      }
      else {
        cFrame.calObj=new CalendarObject();
      }
*/

      File fileEntities=new File("Entity");
      if(fileEntities.exists()) {
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileEntities));
        cFrame.hashEntities=(Hashtable)ois.readObject();
        ois.close();
      }

      cFrame.initializeAppointments();

      cFrame.calCanvas.initializeCanvas();
      cFrame.calCanvas.repaint();

      cFrame.calTimeSlotFrame.calCanvas.initializeCanvas();
      cFrame.calTimeSlotFrame.calCanvas.repaint();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  CalendarExecutor() {
    super();

    appointmentViewerFrame.setCalendarExecutor(this);
    entityViewerFrame.setCalendarExecutor(this);
    calTimeSlotFrame.setCalendarExecutor(this);

    setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    add("Center", calCanvas);

    menuFile.add(menuFileLoad);
    menuFileLoad.addActionListener(this);
    menuFile.add(menuFileSave);
    menuFileSave.addActionListener(this);
    menuFile.add(menuFileExit);
    menuFileExit.addActionListener(this);

    menuOptions.add(menuOptionsCalendar);
    menuOptionsCalendar.add(menuOptionsCalendarSetYear);
    menuOptionsCalendarSetYear.addActionListener(this);
    menuOptionsCalendar.add(menuOptionsCalendarSetMonth);
    menuOptionsCalendarSetMonth.addActionListener(this);

    menuOptions.add(menuOptionsAppointment);
    menuOptionsAppointment.add(menuOptionsAppointmentView);
    menuOptionsAppointmentView.addActionListener(this);
    menuOptionsAppointment.add(menuOptionsAppointmentCalendar);
    menuOptionsAppointmentCalendar.addActionListener(this);
    menuOptionsAppointment.add(menuOptionsAppointmentSchedule);
    menuOptionsAppointmentSchedule.addActionListener(this);
    menuOptionsAppointment.add(menuOptionsAppointmentNew);
    menuOptionsAppointmentNew.addActionListener(this);
    menuOptionsAppointment.add(menuOptionsAppointmentDelete);
    menuOptionsAppointmentDelete.addActionListener(this);

    menuOptions.add(menuOptionsEntity);
    menuOptionsEntity.add(menuOptionsEntityView);
    menuOptionsEntityView.addActionListener(this);
    menuOptionsEntity.add(menuOptionsEntityNew);
    menuOptionsEntityNew.addActionListener(this);
    menuOptionsEntity.add(menuOptionsEntityDelete);
    menuOptionsEntityDelete.addActionListener(this);

    MenuBar mBar=new MenuBar();
    mBar.add(menuFile);
    mBar.add(menuOptions);

    setMenuBar(mBar);
  }

  public void initializeAppointments() {
    TreeMap appointments=calObj.getAppointments();

    Iterator iter0=appointments.entrySet().iterator();
    while(iter0.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter0.next();
      Vector vecAppointments=(Vector)mEntry.getValue();
      for(int i=0;i<vecAppointments.size();i++) {
        AppointmentObject nextAppointment=(AppointmentObject)vecAppointments.elementAt(i);
        EntityObject entities[]=nextAppointment.getEntities();

        for(int ia=0;ia<entities.length;ia++) {
          EntityObject nextEntity=(EntityObject)hashEntities.get(entities[ia].getName());

          Vector vecAppointments2=nextEntity.getAppointments();
          for(int iz=0;iz<vecAppointments2.size();iz++) {
            AppointmentObject nextAppointment2=(AppointmentObject)vecAppointments2.elementAt(iz);
            if(nextAppointment2.getDate().equals(nextAppointment.getDate())) {
              vecAppointments2.setElementAt(nextAppointment, iz);

              break;
            }
          }

          Vector vecAppointmentsMissed2=nextEntity.getAppointmentsMissed();
          for(int iz=0;iz<vecAppointmentsMissed2.size();iz++) {
            AppointmentObject nextAppointment2=(AppointmentObject)vecAppointmentsMissed2.elementAt(iz);
            if(nextAppointment2.getDate().equals(nextAppointment.getDate())) {
              vecAppointmentsMissed2.setElementAt(nextAppointment, iz);

              break;
            }
          }
        }
      }
    }
  }

  public void saveCalendar() {
    if(strCalendarFileName.length()==0)
      return;

    try {
      File fileCalendar=new File(strCalendarFileName);

      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileCalendar));
      oos.writeObject(calObj);
      oos.close();
    }
    catch(Exception ex) {
    }
  }

  public void saveEntities() {
    try {
      File fileEntities=new File("Entity");

      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileEntities));
      oos.writeObject(hashEntities);
      oos.close();
    }
    catch(Exception ex) {
    }
  }

  public Date getDateTimeSlot() {
    TextInputDialog tDialog=new TextInputDialog(this, "New Appointment Dialog: Set Appointment Hour", "Hour:", "Enter Hour");
    tDialog.show();

    if(tDialog.cancelIt)
      return null;

    String strInput=tDialog.getInput();

    int intHour=-1;
    try {
      intHour=Integer.parseInt(strInput);
    }
    catch(Exception ex) {
      MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Appointment Hour", "Hour must be an integer.");
      mDialog.show();

      return null;
    }

    if(intHour<0 || intHour>23) {
      MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Appointment Hour", "Hour must be from 0-23.");
      mDialog.show();

      return null;
    }


    tDialog=new TextInputDialog(this, "New Appointment Dialog: Set Appointment Minute", "Minute:", "Enter Minute");
    tDialog.show();

    if(tDialog.cancelIt)
      return null;

    strInput=tDialog.getInput();

    int intMinute=-1;
    try {
      intMinute=Integer.parseInt(strInput);
    }
    catch(Exception ex) {
      MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Appointment Minute", "Minute must be an integer.");
      mDialog.show();

      return null;
    }

    if(intMinute<0 || intMinute>59) {
      MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Appointment Minute", "Minute must be from 0-59.");
      mDialog.show();

      return null;
    }


    Date dateDate=new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, calCanvas.intSelectedDay, intHour, intMinute);

    return dateDate;
  }

  public void scheduleAppointment(int intCalendarYear, int intCalendarMonth, int intSelectedDay, int intNextTimeHours, int intNextTimeMinutes, int intDurationHours, int intDurationMinutes) {
    Date dateDate=new Date(intCalendarYear-1900, intCalendarMonth, intSelectedDay, intNextTimeHours, intNextTimeMinutes);

    TextInputDialog tDialog=new TextInputDialog(this, "Calendar Appointment Dialog: Set Appointment Name", "Name:", "Enter Name");
    tDialog.show();

    if(tDialog.cancelIt)
      return;

    String strInput=tDialog.getInput();

    String strName=strInput;


    tDialog=new TextInputDialog(this, "Calendar Appointment Dialog: Set Location", "Location:", "Enter Location");
    tDialog.show();

    if(tDialog.cancelIt)
      return;

    String strLocation=tDialog.getInput();


    List lstEntities=new List(5);

    Iterator iter0=hashEntities.entrySet().iterator();
    while(iter0.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter0.next();
      String strEntityName=(String)mEntry.getKey();
      lstEntities.add(strEntityName);
    }

    ListDialog2 lDialog=new ListDialog2(this, "Calendar Appointment Dialog: Entity Selection", lstEntities);
    lDialog.show();

    if(lDialog.cancelIt)
      return;

    int intSelectedIndices[]=lstEntities.getSelectedIndexes();
    EntityObject entities[]=new EntityObject[intSelectedIndices.length];
    for(int i=0;i<intSelectedIndices.length;i++)
      entities[i]=(EntityObject)hashEntities.get(lstEntities.getItem(intSelectedIndices[i]));


    Vector vecAppointments=(Vector)calObj.getAppointments().get(new Date(calTimeSlotFrame.calCanvas.intCalendarYear-1900, calTimeSlotFrame.calCanvas.intCalendarMonth, intSelectedDay));

    int intAppointmentIndex=0;
    boolean blnNewAppointmentOkay=true;

    if(vecAppointments!=null && vecAppointments.size()>0) {
      long lngTime=dateDate.getTime();
      long lngEndTime=lngTime+(new Integer(intDurationHours).longValue()*1000l*60l*60l)+(new Integer(intDurationMinutes).longValue()*1000l*60l);

      for(;intAppointmentIndex<vecAppointments.size();intAppointmentIndex++) {
        AppointmentObject nextAppointment=(AppointmentObject)vecAppointments.elementAt(intAppointmentIndex);
        Date nextDate=nextAppointment.getDate();
        long nextTime=nextDate.getTime();
        long nextTimeEnd=nextTime+(nextAppointment.intDurationHours.longValue()*1000l*60l*60l)+(nextAppointment.intDurationMinutes.longValue()*1000l*60l);

        if(nextTimeEnd>lngTime) {
          if(nextTime>=lngEndTime) {
//new appointment is okay
          }
          else {
//new appointment isn't okay
            blnNewAppointmentOkay=false;
          }
          break;
        }
      }
    }
    else {
      if(vecAppointments==null) {
        vecAppointments=new Vector();
        calObj.getAppointments().put(new Date(calTimeSlotFrame.calCanvas.intCalendarYear-1900, calTimeSlotFrame.calCanvas.intCalendarMonth, intSelectedDay), vecAppointments);
      }
      else {
//empty
      }
    }

    if(!blnNewAppointmentOkay) {
      MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: Conflict In Timing", "Appointment in the same time slot already exists.");
      mDialog.show();

      return;
    }

    AppointmentObject appointmentObj=new AppointmentObject(strName, dateDate, intDurationHours, intDurationMinutes, strLocation, entities);

    vecAppointments.insertElementAt(appointmentObj, intAppointmentIndex);

    saveCalendar();

    calCanvas.repaint();

    for(int i=0;i<entities.length;i++)
      entities[i].getAppointments().addElement(appointmentObj);

    saveEntities();
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==menuFileLoad) {
      JFileChooser fDialog=new JFileChooser();
      fDialog.setCurrentDirectory(new File("."));
      fDialog.setDialogTitle("Load Calendar");
      fDialog.setMultiSelectionEnabled(false);
      fDialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
      int intResp=fDialog.showOpenDialog(this);

      if(intResp==JFileChooser.APPROVE_OPTION) {
        try {
          File fileFile=fDialog.getSelectedFile();

          ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileFile));
          calObj=(CalendarObject)ois.readObject();
          ois.close();

          strCalendarFileName=fileFile.getAbsolutePath();

          calCanvas.repaint();
        }
        catch(Exception ex) {
        }
      }
    }
    else if(evSource==menuFileSave) {
      JFileChooser fDialog=new JFileChooser();
      fDialog.setCurrentDirectory(new File("."));
      fDialog.setDialogTitle("Save Calendar");
      fDialog.setMultiSelectionEnabled(false);
      fDialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
      int intResp=fDialog.showSaveDialog(this);

      if(intResp==JFileChooser.APPROVE_OPTION) {
        try {
          File fileFile=fDialog.getSelectedFile();

          ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileFile));
          oos.writeObject(calObj);
          oos.close();

          strCalendarFileName=fileFile.getAbsolutePath();

          calCanvas.repaint();
        }
        catch(Exception ex) {
        }
      }
    }
    else if(evSource==menuFileExit) {
      System.exit(0);
    }
    else if(evSource==menuOptionsCalendarSetYear) {
      TextInputDialog tDialog=new TextInputDialog(this, "Calendar Set Year Dialog", "Year:", "Set Year");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strInput=tDialog.getInput();

      if(strInput.length()!=4) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Set Year Dialog", "The year entered must be 4 digits long.");
        mDialog.show();

        return;
      }

      int intInput=-1;
      try {
        intInput=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Set Year Dialog", "The year entered must be an integer.");
        mDialog.show();

        return;
      }

      calCanvas.intCalendarYear=intInput;

      calCanvas.repaint();
    }
    else if(evSource==menuOptionsCalendarSetMonth) {
      TextInputDialog tDialog=new TextInputDialog(this, "Calendar Set Month Dialog", "Month:", "Set Month");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strInput=tDialog.getInput();

      int intInput=-1;

      if(strInput.equals("January"))
        intInput=0;
      else if(strInput.equals("February"))
        intInput=1;
      else if(strInput.equals("March"))
        intInput=2;
      else if(strInput.equals("April"))
        intInput=3;
      else if(strInput.equals("May"))
        intInput=4;
      else if(strInput.equals("June"))
        intInput=5;
      else if(strInput.equals("July"))
        intInput=6;
      else if(strInput.equals("August"))
        intInput=7;
      else if(strInput.equals("September"))
        intInput=8;
      else if(strInput.equals("October"))
        intInput=9;
      else if(strInput.equals("November"))
        intInput=10;
      else if(strInput.equals("December"))
        intInput=11;
      else {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Set Month Dialog", "The month entered was not recognized.");
        mDialog.show();

        return;
      }

      calCanvas.intCalendarMonth=intInput;

      calCanvas.repaint();
    }
    else if(evSource==menuOptionsAppointmentView) {
      Vector vecCalendarAppointments=(Vector)calObj.getAppointments().get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, calCanvas.intSelectedDay));

      if(vecCalendarAppointments==null)
        return;

      if(vecCalendarAppointments.size()==0)
        return;

      List lstList=new List(5);
      for(int i=0;i<vecCalendarAppointments.size();i++) {
        AppointmentObject nextAppointment=(AppointmentObject)vecCalendarAppointments.elementAt(i);
        Date dateDate=nextAppointment.getDate();
        String strDisplay=String.valueOf(dateDate.getHours());
        String strMinutes=String.valueOf(dateDate.getMinutes());
        if(strMinutes.length()==1)
          strMinutes="0"+strMinutes;
        strDisplay+=":"+strMinutes;
        strDisplay+=", "+nextAppointment.getLocation();

        lstList.add(strDisplay);
      }

      ListDialog lDialog=new ListDialog(this, "View Appointments Dialog", lstList);
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      int intAppointmentIndex=lstList.getSelectedIndex();

      appointmentViewerFrame.setAppointment((AppointmentObject)vecCalendarAppointments.elementAt(intAppointmentIndex));
      appointmentViewerFrame.setVisible(true);
    }
    else if(evSource==menuOptionsAppointmentCalendar) {
      TextInputDialog tDialog=new TextInputDialog(this, "Calendar Appointment Dialog: From Hour", "From Hour:", "Enter From Hour");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strInput=tDialog.getInput();

      int intFromHour=-1;
      try {
        intFromHour=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: From Hour", "From hour must be an integer.");
        mDialog.show();

        return;
      }

      if(intFromHour<0 || intFromHour>23) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: From Hour", "From hour must be from 0-23.");
        mDialog.show();

        return;
      }


      tDialog=new TextInputDialog(this, "Calendar Appointment Dialog: To Hour", "To Hour:", "Enter To Hour");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      strInput=tDialog.getInput();

      int intToHour=-1;
      try {
        intToHour=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: To Hour", "To hour must be an integer.");
        mDialog.show();

        return;
      }

      if(intToHour<0 || intToHour>23) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: To Hour", "To hour must be from 0-23.");
        mDialog.show();

        return;
      }


      if(intToHour<=intFromHour) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: To Hour", "To hour must be greater than from hour.");
        mDialog.show();

        return;
      }


      tDialog=new TextInputDialog(this, "Calendar Appointment Dialog: Duration Hours", "Duration Hours:", "Enter Duration Hours");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      strInput=tDialog.getInput();

      int intDurationHours=-1;
      try {
        intDurationHours=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: Duration Hours", "Duration hours must be an integer.");
        mDialog.show();

        return;
      }

      if(intDurationHours<0) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: Duration Hours", "Duration hours must be greater than or equal to 0.");
        mDialog.show();

        return;
      }
      else if(intDurationHours>8) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: Duration Hours", "Duration hours can't be greater than 8.");
        mDialog.show();

        return;
      }


      tDialog=new TextInputDialog(this, "Calendar Appointment Dialog: Duration Minutes", "Duration Minutes:", "Enter Duration Minutes");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      strInput=tDialog.getInput();

      int intDurationMinutes=-1;
      try {
        intDurationMinutes=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: Duration Minutes", "Duration minutes must be an integer.");
        mDialog.show();

        return;
      }

      if(intDurationMinutes<0) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: Duration Minutes", "Duration minutes must be greater than or equal to 0.");
        mDialog.show();

        return;
      }
      else if(intDurationMinutes>59) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: Duration Minutes", "Duration minutes can't be greater than 59.");
        mDialog.show();

        return;
      }

      if(intDurationHours==0 && intDurationMinutes==0) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Appointment Dialog: Duration", "Duration hours and minutes can't both be 0.");
        mDialog.show();

        return;
      }


      calTimeSlotFrame.set(intDurationHours, intDurationMinutes, intFromHour, intToHour);
      calTimeSlotFrame.setVisible(true);
    }
    else if(evSource==menuOptionsAppointmentSchedule) {
      TextInputDialog tDialog=new TextInputDialog(this, "Schedule Appointment Dialog: Set Appointment Name", "Name:", "Enter Name");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strInput=tDialog.getInput();

      String strName=strInput;


      tDialog=new TextInputDialog(this, "Schedule Appointment Dialog: Number of Time Slots to Check", "Number of time slots:", "Enter Number");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      strInput=tDialog.getInput();

      int intNumberOfTimeSlots=-1;
      try {
        intNumberOfTimeSlots=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Number of Time Slots to Check", "Number of time slots must be an integer.");
        mDialog.show();

        return;
      }


      Date dateTimeSlots[]=new Date[intNumberOfTimeSlots];
      for(int i=0;i<dateTimeSlots.length;i++) {
        dateTimeSlots[i]=getDateTimeSlot();
        if(dateTimeSlots[i]==null)
          return;
      }


      tDialog=new TextInputDialog(this, "Schedule Appointment Dialog: Set Appointment Duration Hour", "Duration Hour:", "Enter Duration Hour");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      strInput=tDialog.getInput();

      int intDurationHour=-1;
      try {
        intDurationHour=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Set Appointment Duration Hour", "Duration hour must be an integer.");
        mDialog.show();

        return;
      }

      if(intDurationHour<0) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Set Appointment Duration Hour", "Duration hour must be greater than or equal to 0.");
        mDialog.show();

        return;
      }
      else if(intDurationHour>8) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Set Appointment Duration Hour", "Duration hour can't be greater than 8.");
        mDialog.show();

        return;
      }


      tDialog=new TextInputDialog(this, "Schedule Appointment Dialog: Set Appointment Duration Minute", "Duration Minute:", "Enter Duration Minute");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      strInput=tDialog.getInput();

      int intDurationMinute=-1;
      try {
        intDurationMinute=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Set Appointment Duration Minute", "Duration minute must be an integer.");
        mDialog.show();

        return;
      }

      if(intDurationMinute<0) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Set Appointment Duration Minute", "Duration minute must be greater than or equal to 0.");
        mDialog.show();

        return;
      }
      else if(intDurationMinute>59) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Set Appointment Duration Minute", "Duration minute can't be greater than 59.");
        mDialog.show();

        return;
      }

      if(intDurationHour==0 && intDurationMinute==0) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Set Appointment Duration", "Duration hour and minute can't both be 0.");
        mDialog.show();

        return;
      }


      for(int i=0;i<dateTimeSlots.length;i++) {
        double dblDTSH=(double)dateTimeSlots[i].getHours();
        double dblDTSM=(double)dateTimeSlots[i].getMinutes();

        double dblDurationHour=(double)intDurationHour;
        double dblDurationMinute=(double)intDurationMinute;

        double dblEndTime=dblDTSH+(dblDTSM/60.0d)+dblDurationHour+(dblDurationMinute/60.0d);

        if(dblEndTime>=24.0d) {
          MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Set Appointment End Time", "Appointment end time can't be greater than or equal to 24.");
          mDialog.show();

          return;
        }
      }


      tDialog=new TextInputDialog(this, "Schedule Appointment Dialog: Set Location", "Location:", "Enter Location");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strLocation=tDialog.getInput();

/*
      tDialog=new TextInputDialog(this, "Schedule Appointment Dialog: Set Number of Entities", "Number of entities:", "Enter Number of Entities");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      strInput=tDialog.getInput();

      int intNumberOfEntities=-1;
      try {
        intNumberOfEntities=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Set Number of Entities", "Number of entities must be an integer.");
        mDialog.show();

        return;
      }
*/

      List lstEntities=new List(5);

      Iterator iter0=hashEntities.entrySet().iterator();
      while(iter0.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter0.next();
        String strEntityName=(String)mEntry.getKey();
        lstEntities.add(strEntityName);
      }

      ListDialog2 lDialog=new ListDialog2(this, "Schedule Appointment Dialog: Entity Selection", lstEntities);
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      int intSelectedIndices[]=lstEntities.getSelectedIndexes();
      EntityObject entities[]=new EntityObject[intSelectedIndices.length];
      for(int i=0;i<intSelectedIndices.length;i++)
        entities[i]=(EntityObject)hashEntities.get(lstEntities.getItem(intSelectedIndices[i]));


      Vector vecAppointments=(Vector)calObj.getAppointments().get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, calCanvas.intSelectedDay));


      for(int iz=0;iz<dateTimeSlots.length;iz++) {
        Date dateDate=dateTimeSlots[iz];

        int intAppointmentIndex=0;
        boolean blnNewAppointmentOkay=true;

        if(vecAppointments!=null && vecAppointments.size()>0) {
          long lngTime=dateDate.getTime();
          long lngEndTime=lngTime+(new Integer(intDurationHour).longValue()*1000l*60l*60l)+(new Integer(intDurationMinute).longValue()*1000l*60l);

          for(;intAppointmentIndex<vecAppointments.size();intAppointmentIndex++) {
            AppointmentObject nextAppointment=(AppointmentObject)vecAppointments.elementAt(intAppointmentIndex);
            Date nextDate=nextAppointment.getDate();
            long nextTime=nextDate.getTime();
            long nextTimeEnd=nextTime+(nextAppointment.intDurationHours.longValue()*1000l*60l*60l)+(nextAppointment.intDurationMinutes.longValue()*1000l*60l);

            if(nextTimeEnd>lngTime) {
              if(nextTime>=lngEndTime) {
//new appointment is okay
              }
              else {
//new appointment isn't okay
                blnNewAppointmentOkay=false;
              }
              break;
            }
          }
        }
        else {
          if(vecAppointments==null) {
            vecAppointments=new Vector();
            calObj.getAppointments().put(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, calCanvas.intSelectedDay), vecAppointments);
          }
          else {
//empty
          }
        }

        if(!blnNewAppointmentOkay && iz==(dateTimeSlots.length-1)) {
          MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Conflict In Timing", "Appointment in the same time slots already exists.");
          mDialog.show();

          return;
        }

        if(blnNewAppointmentOkay) {
          AppointmentObject appointmentObj=new AppointmentObject(strName, dateDate, intDurationHour, intDurationMinute, strLocation, entities);

          vecAppointments.insertElementAt(appointmentObj, intAppointmentIndex);

          saveCalendar();

          calCanvas.repaint();


          for(int i=0;i<entities.length;i++)
            entities[i].getAppointments().addElement(appointmentObj);

          saveEntities();


          MessageDialog mDialog=new MessageDialog(this, "Schedule Appointment Dialog: Appointment Scheduled", "Appointment scheduled for: "+dateDate.toString());
          mDialog.show();

          return;
        }
      }
    }
    else if(evSource==menuOptionsAppointmentNew) {
      TextInputDialog tDialog=new TextInputDialog(this, "New Appointment Dialog: Set Appointment Name", "Name:", "Enter Name");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strInput=tDialog.getInput();

      String strName=strInput;


      Date dateDate=getDateTimeSlot();
      if(dateDate==null)
        return;


      tDialog=new TextInputDialog(this, "New Appointment Dialog: Set Appointment Duration Hour", "Duration Hour:", "Enter Duration Hour");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      strInput=tDialog.getInput();

      int intDurationHour=-1;
      try {
        intDurationHour=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Appointment Duration Hour", "Duration hour must be an integer.");
        mDialog.show();

        return;
      }

      if(intDurationHour<0) {
        MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Appointment Duration Hour", "Duration hour must be greater than or equal to 0.");
        mDialog.show();

        return;
      }
      else if(intDurationHour>8) {
        MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Appointment Duration Hour", "Duration hour can't be greater than 8.");
        mDialog.show();

        return;
      }


      tDialog=new TextInputDialog(this, "New Appointment Dialog: Set Appointment Duration Minute", "Duration Minute:", "Enter Duration Minute");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      strInput=tDialog.getInput();

      int intDurationMinute=-1;
      try {
        intDurationMinute=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Appointment Duration Minute", "Duration minute must be an integer.");
        mDialog.show();

        return;
      }

      if(intDurationMinute<0) {
        MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Appointment Duration Minute", "Duration minute must be greater than or equal to 0.");
        mDialog.show();

        return;
      }
      else if(intDurationMinute>59) {
        MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Appointment Duration Minute", "Duration minute can't be greater than 59.");
        mDialog.show();

        return;
      }


      if(intDurationHour==0 && intDurationMinute==0) {
        MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Appointment Duration", "Duration hour and minute can't both be 0.");
        mDialog.show();

        return;
      }


      double dblDTSH=(double)dateDate.getHours();
      double dblDTSM=(double)dateDate.getMinutes();

      double dblDurationHour=(double)intDurationHour;
      double dblDurationMinute=(double)intDurationMinute;

      double dblEndTime=dblDTSH+(dblDTSM/60.0d)+dblDurationHour+(dblDurationMinute/60.0d);

      if(dblEndTime>=24.0d) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Schedule Appointment Dialog: Set Appointment End Time", "Appointment end time can't be greater than or equal to 24.");
        mDialog.show();

        return;
      }


      tDialog=new TextInputDialog(this, "New Appointment Dialog: Set Location", "Location:", "Enter Location");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strLocation=tDialog.getInput();

/*
      tDialog=new TextInputDialog(this, "New Appointment Dialog: Set Number of Entities", "Number of entities:", "Enter Number of Entities");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      strInput=tDialog.getInput();

      int intNumberOfEntities=-1;
      try {
        intNumberOfEntities=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Set Number of Entities", "Number of entities must be an integer.");
        mDialog.show();

        return;
      }
*/

      List lstEntities=new List(5);

      Iterator iter0=hashEntities.entrySet().iterator();
      while(iter0.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter0.next();
        String strEntityName=(String)mEntry.getKey();
        lstEntities.add(strEntityName);
      }

      ListDialog2 lDialog=new ListDialog2(this, "New Appointment Dialog: Entity Selection", lstEntities);
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      int intSelectedIndices[]=lstEntities.getSelectedIndexes();
      EntityObject entities[]=new EntityObject[intSelectedIndices.length];
      for(int i=0;i<intSelectedIndices.length;i++)
        entities[i]=(EntityObject)hashEntities.get(lstEntities.getItem(intSelectedIndices[i]));


      Vector vecAppointments=(Vector)calObj.getAppointments().get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, calCanvas.intSelectedDay));

      int intAppointmentIndex=0;
      boolean blnNewAppointmentOkay=true;

      if(vecAppointments!=null && vecAppointments.size()>0) {
        long lngTime=dateDate.getTime();
        long lngEndTime=lngTime+(new Integer(intDurationHour).longValue()*1000l*60l*60l)+(new Integer(intDurationMinute).longValue()*1000l*60l);

        for(;intAppointmentIndex<vecAppointments.size();intAppointmentIndex++) {
          AppointmentObject nextAppointment=(AppointmentObject)vecAppointments.elementAt(intAppointmentIndex);
          Date nextDate=nextAppointment.getDate();
          long nextTime=nextDate.getTime();
          long nextTimeEnd=nextTime+(nextAppointment.intDurationHours.longValue()*1000l*60l*60l)+(nextAppointment.intDurationMinutes.longValue()*1000l*60l);

          if(nextTimeEnd>lngTime) {
            if(nextTime>=lngEndTime) {
//new appointment is okay
            }
            else {
//new appointment isn't okay
              blnNewAppointmentOkay=false;
            }
            break;
          }
        }
      }
      else {
        if(vecAppointments==null) {
          vecAppointments=new Vector();
          calObj.getAppointments().put(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, calCanvas.intSelectedDay), vecAppointments);
        }
        else {
//empty
        }
      }

      if(!blnNewAppointmentOkay) {
        MessageDialog mDialog=new MessageDialog(this, "Error. New Appointment Dialog: Conflict In Timing", "Appointment in the same time slot already exists.");
        mDialog.show();

        return;
      }

      AppointmentObject appointmentObj=new AppointmentObject(strName, dateDate, intDurationHour, intDurationMinute, strLocation, entities);

      vecAppointments.insertElementAt(appointmentObj, intAppointmentIndex);

      saveCalendar();

      calCanvas.repaint();

      for(int i=0;i<entities.length;i++)
        entities[i].getAppointments().addElement(appointmentObj);

      saveEntities();
    }
    else if(evSource==menuOptionsAppointmentDelete) {
      Vector vecCalendarAppointments=(Vector)calObj.getAppointments().get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, calCanvas.intSelectedDay));

      List lstList=new List(5);
      for(int i=0;i<vecCalendarAppointments.size();i++) {
        AppointmentObject nextAppointment=(AppointmentObject)vecCalendarAppointments.elementAt(i);
        Date dateDate=nextAppointment.getDate();
        String strDisplay=String.valueOf(dateDate.getHours());
        String strMinutes=String.valueOf(dateDate.getMinutes());
        if(strMinutes.length()==1)
          strMinutes="0"+strMinutes;
        strDisplay+=":"+strMinutes;
        strDisplay+=", "+nextAppointment.getLocation();

        lstList.add(strDisplay);
      }

      ListDialog lDialog=new ListDialog(this, "Delete Appointments Dialog", lstList);
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      int intAppointmentIndex=lstList.getSelectedIndex();

      vecCalendarAppointments.removeElementAt(intAppointmentIndex);

      saveCalendar();

      calCanvas.repaint();
    }
    else if(evSource==menuOptionsEntityView) {
      String strEntities[]=new String[hashEntities.size()];
      int intCountE=0;
      Iterator iter0=hashEntities.entrySet().iterator();
      while(iter0.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter0.next();
        strEntities[intCountE++]=(String)mEntry.getKey();
      }

      Arrays.sort(strEntities);

      List lstList=new List(5);

      for(int i=0;i<strEntities.length;i++)
        lstList.add(strEntities[i]);

      ListDialog lDialog=new ListDialog(this, "View Entity Dialog", lstList);
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      int intEntityIndex=lstList.getSelectedIndex();

      String strEntity=lstList.getItem(intEntityIndex);

      EntityObject entityObj=(EntityObject)hashEntities.get(strEntity);

      entityViewerFrame.setEntity(entityObj);
      entityViewerFrame.setVisible(true);
    }
    else if(evSource==menuOptionsEntityNew) {
      TextInputDialog tDialog=new TextInputDialog(this, "New Entity Dialog: Entity Name", "Entity Name: ", "Enter Name");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strEntity=tDialog.getInput();

      if(hashEntities.containsKey(strEntity)) {
        MessageDialog mDialog=new MessageDialog(this, "Error. New Entity Dialog: Entity Already Exists", "An entity with the same name already exists.");
        mDialog.show();

        return;
      }

      hashEntities.put(strEntity, new EntityObject(strEntity));

      saveEntities();
    }
    else if(evSource==menuOptionsEntityDelete) {
      String strEntities[]=new String[hashEntities.size()];
      int intCountE=0;
      Iterator iter0=hashEntities.entrySet().iterator();
      while(iter0.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter0.next();
        strEntities[intCountE++]=(String)mEntry.getKey();
      }

      Arrays.sort(strEntities);

      List lstList=new List(5);

      for(int i=0;i<strEntities.length;i++)
        lstList.add(strEntities[i]);

      ListDialog lDialog=new ListDialog(this, "View Entity Dialog", lstList);
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      int intEntityIndex=lstList.getSelectedIndex();

      String strEntity=lstList.getItem(intEntityIndex);

      EntityObject entity=(EntityObject)hashEntities.remove(strEntity);

      saveEntities();

/*
      Vector vecAppointments=entity.getAppointments();

      for(int i=0;i<vecAppointments.size();i++) {
        AppointmentObject nextAppointment=(AppointmentObject)vecAppointments.elementAt(i);

        EntityObject entities[]=nextAppointment.getEntities();

        EntityObject entities2[]=new EntityObject[entities.length-1];

        int ia=0;
        for(;ia<entities.length;ia++) {
          if(entities[ia].getName().equals(strEntity)) {
            ++ia;
            break;
          }

          entities2[ia]=entities[ia];
        }

        for(;ia<entities.length;ia++) {
          entities2[ia-1]=entities[ia];
        }

        nextAppointment.setEntities(entities2);
      }

      saveCalendar();
*/

    }
  }

  class CalendarCanvas extends Canvas
  implements MouseListener {
    String strCalendarMonth[]={"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    String strWeekDays[]={"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

    int intDayWidth=-1;
    int intDayHeight=-1;

    int intCalendarYear=-1;
    int intCalendarMonth=-1;

    int intCharHeight=-1;

    int intSelectedDay=1;

    CalendarCanvas() {
      super();

      addMouseListener(this);
    }

    public void initializeCanvas() {
      Date dateNow=new Date();
      intCalendarYear=dateNow.getYear()+1900;
      intCalendarMonth=dateNow.getMonth();
    }

    public void initializeCanvas2() {
      Dimension canvasDim=getSize();

      int intHeight=canvasDim.height;
      intHeight-=(intCharHeight*2+10);

      intDayWidth=canvasDim.width/7;
      intDayHeight=intHeight/6;
    }

    public void mouseEntered(MouseEvent me) {
    }

    public void mouseExited(MouseEvent me) {
    }

    public void mousePressed(MouseEvent me) {
    }

    public void mouseReleased(MouseEvent me) {
    }

    public void mouseClicked(MouseEvent me) {
      Point mePoint=me.getPoint();

      int meX=mePoint.x;
      int meY=mePoint.y;

      meY-=(intCharHeight*2+10);

      int intSelectedX=meX/intDayWidth;
      int intSelectedY=meY/intDayHeight;

      GregorianCalendar gCal=new GregorianCalendar(intCalendarYear, intCalendarMonth, 1);

      int intDayOfWeek=gCal.get(Calendar.DAY_OF_WEEK);
      --intDayOfWeek;
//0 is sunday and 6 is saturday

      int intDay=1;

      for(int i=intDayOfWeek;i<7;i++) {
        if(intSelectedY==0 && i==intSelectedX) {
          intSelectedDay=intDay;
          repaint();
          return;
        }

        ++intDay;
      }

      int intNextY=1;


      while(true) {
        for(int i=0;i<7;i++) {
          if(intSelectedY==intNextY && intSelectedX==i) {
            intSelectedDay=intDay;
            repaint();
            return;
          }

          ++intDay;

          gCal.set(Calendar.DAY_OF_MONTH, intDay);

          if(gCal.get(Calendar.DAY_OF_MONTH)==1) {
            return;
          }
        }

        ++intNextY;
      }      
    }

    public void paint(Graphics graph) {
      if(intCalendarMonth==-1)
        return;

      if(intCharHeight==-1) {
        FontMetrics fMetr=graph.getFontMetrics();
        intCharHeight=fMetr.getHeight();

        initializeCanvas2();
      }

      graph.drawString(String.valueOf(intCalendarYear)+" : "+strCalendarMonth[intCalendarMonth], 5, intCharHeight+5);

      int intXPosition=0;

      for(int i=0;i<7;i++) {
        graph.drawString(strWeekDays[i], intXPosition, intCharHeight+5+intCharHeight+5);

        intXPosition+=intDayWidth;
      }

      for(int i=0;i<=7;i++) {
        graph.drawLine(i*intDayWidth, intCharHeight*2+10, i*intDayWidth, getSize().height);
      }

      graph.drawLine(0, 0, getSize().width, 0);

      graph.drawLine(0, intCharHeight+5, getSize().width, intCharHeight+5);

      for(int i=0;i<=6;i++) {
        graph.drawLine(0, i*intDayHeight+intCharHeight*2+10, getSize().width, i*intDayHeight+intCharHeight*2+10);
      }

      GregorianCalendar gCal=new GregorianCalendar(intCalendarYear, intCalendarMonth, 1);

      int intDayOfWeek=gCal.get(Calendar.DAY_OF_WEEK);
      --intDayOfWeek;
//0 is sunday and 6 is saturday

      intXPosition=intDayOfWeek*intDayWidth;

      int intDay=1;

      for(int i=intDayOfWeek;i<7;i++) {
        if(intSelectedDay==intDay) {
          graph.setColor(Color.green);
          graph.fillRect(intXPosition, intCharHeight*2+10, intDayWidth, intDayHeight);
          graph.setColor(Color.black);
        }
        else {
          Vector vecAppointments=(Vector)calObj.getAppointments().get(new Date(intCalendarYear-1900, intCalendarMonth, intDay));
          if(vecAppointments!=null) {
            if(vecAppointments.size()>0) {
              graph.setColor(Color.red);
              graph.fillRect(intXPosition, intCharHeight*2+10, intDayWidth, intDayHeight);
              graph.setColor(Color.black);
            }
          }
        }

        graph.drawString(String.valueOf(intDay), intXPosition+5, intCharHeight+5+intCharHeight+5+intCharHeight+5);

        ++intDay;

        intXPosition+=intDayWidth;
      }

      int intYPosition=intCharHeight+5+intCharHeight+5;
      intYPosition+=intDayHeight;

      while(true) {
        intXPosition=0;

        boolean blnMustBreak=false;
        for(int i=0;i<7;i++) {
          if(intSelectedDay==intDay) {
            graph.setColor(Color.green);
            graph.fillRect(intXPosition, intYPosition, intDayWidth, intDayHeight);
            graph.setColor(Color.black);
          }
          else {
            Vector vecAppointments=(Vector)calObj.getAppointments().get(new Date(intCalendarYear-1900, intCalendarMonth, intDay));
            if(vecAppointments!=null) {
              if(vecAppointments.size()>0) {
                graph.setColor(Color.red);
                graph.fillRect(intXPosition, intYPosition, intDayWidth, intDayHeight);
                graph.setColor(Color.black);
              }
            }
          }

          graph.drawString(String.valueOf(intDay), intXPosition+5, intYPosition+intCharHeight+5);

          ++intDay;

          intXPosition+=intDayWidth;

          gCal.set(Calendar.DAY_OF_MONTH, intDay);

          if(gCal.get(Calendar.DAY_OF_MONTH)==1) {
            blnMustBreak=true;
            break;
          }
        }

        if(blnMustBreak)
          break;

        intYPosition+=intDayHeight;
      }
    }
  }
}
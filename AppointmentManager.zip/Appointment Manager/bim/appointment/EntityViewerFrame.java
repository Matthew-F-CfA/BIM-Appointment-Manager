package bim.appointment;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Vector;

class EntityViewerFrame extends Frame
implements ActionListener {
  EntityViewerFrame refThis;
  CalendarExecutor calExecutor;
  EntityObject entity;

  Label lblName=new Label("");

  TextArea txtDescription=new TextArea(5, 100);
  Button btnSetDescription=new Button("Set Description");

  Label lblRating=new Label("");
  Button btnSetRating=new Button("Set Rating");

  Label lblRatingCount=new Label("");
  Button btnAddRating=new Button("Add Rating");

  TextArea txtNotes=new TextArea(5, 100);
  Button btnSetNotes=new Button("Set Notes");

  List lstAppointments=new List(5);
  Button btnViewAppointment=new Button("View Appointment");
  Button btnAddAppointmentToMissed=new Button("Add Appointment to Missed");
  Button btnRemoveAppointment=new Button("Remove Appointment");

  List lstAppointmentsMissed=new List(5);
  Button btnViewAppointmentMissed=new Button("View Appointment Missed");
  Button btnRemoveAppointmentMissed=new Button("Remove Appointment Missed");


  EntityViewerFrame() {
    super();
    refThis=this;

    setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        refThis.setVisible(false);
      }
    });

    Panel tempPan=new Panel();
    tempPan.setLayout(new BorderLayout());
    Panel tempPanA=new Panel();
    tempPanA.setLayout(new GridLayout(2, 1));
    Panel tempPanA1=new Panel();
    tempPanA1.setLayout(new BorderLayout());
    tempPanA1.add("West", new Label("Name: "));
    tempPanA1.add("Center", lblName);
    tempPanA.add(tempPanA1);
    tempPanA.add(new Label("Description:"));
    tempPan.add("North", tempPanA);
    tempPan.add("Center", txtDescription);
    Panel tempPanB=new Panel();
    tempPanB.setLayout(new GridLayout(3, 1));
    tempPanB.add(btnSetDescription);
    btnSetDescription.addActionListener(this);
    Panel tempPanB1=new Panel();
    tempPanB1.setLayout(new BorderLayout());
    tempPanB1.add("West", new Label("Rating: "));
    tempPanB1.add("Center", lblRating);
    tempPanB1.add("East", btnSetRating);
    btnSetRating.addActionListener(this);
    tempPanB.add(tempPanB1);
    Panel tempPanB2=new Panel();
    tempPanB2.setLayout(new BorderLayout());
    tempPanB2.add("West", new Label("Rating Count: "));
    tempPanB2.add("Center", lblRatingCount);
    tempPanB2.add("East", btnAddRating);
    btnAddRating.addActionListener(this);
    tempPanB.add(tempPanB2);
    tempPan.add("South", tempPanB);
    add("North", tempPan);

    Panel tempPan2=new Panel();
    tempPan2.setLayout(new BorderLayout());
    tempPan2.add("North", new Label("Notes:"));
    tempPan2.add("Center", txtNotes);
    tempPan2.add("South", btnSetNotes);
    btnSetNotes.addActionListener(this);
    add("Center", tempPan2);

    Panel tempPan3=new Panel();
    tempPan3.setLayout(new GridLayout(2, 1));
    Panel tempPan3A=new Panel();
    tempPan3A.setLayout(new BorderLayout());
    tempPan3A.add("North", new Label("Appointments:"));
    tempPan3A.add("Center", lstAppointments);
    Panel tempPan3A1=new Panel(); 
    tempPan3A1.setLayout(new GridLayout(3, 1));
    tempPan3A1.add(btnViewAppointment);
    btnViewAppointment.addActionListener(this);
    tempPan3A1.add(btnAddAppointmentToMissed);
    btnAddAppointmentToMissed.addActionListener(this);
    tempPan3A1.add(btnRemoveAppointment);
    btnRemoveAppointment.addActionListener(this);
    tempPan3A.add("South", tempPan3A1);
    tempPan3.add(tempPan3A);
    Panel tempPan3B=new Panel();
    tempPan3B.setLayout(new BorderLayout());
    tempPan3B.add("North", new Label("Appointments Missed:"));
    tempPan3B.add("Center", lstAppointmentsMissed);
    Panel tempPan3B1=new Panel();
    tempPan3B1.setLayout(new GridLayout(2, 1));
    tempPan3B1.add(btnViewAppointmentMissed);
    btnViewAppointmentMissed.addActionListener(this);
    tempPan3B1.add(btnRemoveAppointmentMissed);
    btnRemoveAppointmentMissed.addActionListener(this);
    tempPan3B.add("South", tempPan3B1);
    tempPan3.add(tempPan3B);
    add("South", tempPan3);
  }

  public void setCalendarExecutor(CalendarExecutor calExecutor) {
    this.calExecutor=calExecutor;
  }

  public void setEntity(EntityObject entity) {
    this.entity=entity;

    lblName.setText(entity.getName());

    txtDescription.setText(entity.getDescription());

    lblRating.setText(String.valueOf(entity.getRating()));

    lblRatingCount.setText(String.valueOf(entity.getRatingCount()));

    txtNotes.setText(entity.getNotes());

    Vector vecAppointments=entity.getAppointments();
    lstAppointments.removeAll();
    for(int i=0;i<vecAppointments.size();i++) {
      AppointmentObject nextAppointment=(AppointmentObject)vecAppointments.elementAt(i);
      lstAppointments.add(nextAppointment.getDate().toString());
    }

    Vector vecAppointmentsMissed=entity.getAppointmentsMissed();
    lstAppointmentsMissed.removeAll();
    for(int i=0;i<vecAppointmentsMissed.size();i++) {
      AppointmentObject nextAppointment=(AppointmentObject)vecAppointmentsMissed.elementAt(i);
      lstAppointmentsMissed.add(nextAppointment.getDate().toString());
    }
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnSetDescription) {
      String strDescription=txtDescription.getText();

      entity.setDescription(strDescription);

      calExecutor.saveEntities();
    }
    else if(evSource==btnSetRating) {
      TextInputDialog tDialog=new TextInputDialog(this, "Set Rating and Weight Dialog", "Rating:", "Set Rating");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strRating=tDialog.getInput();

      int intRating=-1;
      try {
        intRating=Integer.parseInt(strRating);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Set Rating and Weight Dialog", "Rating must be an integer.");
        mDialog.show();

        return;
      }

      if(intRating<0 || intRating>10) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Set Rating and Weight Dialog", "Rating must be an integer from 0-10.");
        mDialog.show();

        return;
      }


      tDialog=new TextInputDialog(this, "Set Rating and Weight Dialog", "Rating Weight:", "Set Rating Weight");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strRatingWeight=tDialog.getInput();

      int intRatingWeight=-1;
      try {
        intRatingWeight=Integer.parseInt(strRatingWeight);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Set Rating and Weight Dialog", "Rating weight must be an integer.");
        mDialog.show();

        return;
      }

      if(intRatingWeight<1) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Set Rating and Weight Dialog", "Rating must be an integer greater than 0.");
        mDialog.show();

        return;
      }


      entity.setRating(intRating);
      entity.setRatingCount(intRatingWeight);
      entity.setRatingReal(new Integer(intRating).doubleValue());

      lblRating.setText(String.valueOf(intRating));
      lblRatingCount.setText(String.valueOf(intRatingWeight));

      calExecutor.saveEntities();
    }
    else if(evSource==btnAddRating) {
      TextInputDialog tDialog=new TextInputDialog(this, "Add Rating Dialog", "Rating:", "Add Rating");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strRating=tDialog.getInput();

      int intRating=-1;
      try {
        intRating=Integer.parseInt(strRating);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Add Rating Dialog", "Rating must be an integer.");
        mDialog.show();

        return;
      }

      if(intRating<0 || intRating>10) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Add Rating Dialog", "Rating must be an integer from 0-10.");
        mDialog.show();

        return;
      }

      double dblRating=new Integer(intRating).doubleValue();

      double dblRatingReal=entity.getRatingReal();

      double dblCount=new Integer(entity.getRatingCount()).doubleValue();

      double dblNewRatingReal=dblRatingReal*dblCount/(dblCount+1.0d)+dblRating*(1.0d/(dblCount+1.0d));

      entity.setRatingReal(dblNewRatingReal);

      entity.setRatingCount(entity.getRatingCount()+1);

      entity.setRating((int)Math.rint(dblNewRatingReal));

      lblRating.setText(String.valueOf(entity.getRating()));
      lblRatingCount.setText(String.valueOf(entity.getRatingCount()));

      calExecutor.saveEntities();
    }
    else if(evSource==btnSetNotes) {
      String strNotes=txtNotes.getText();

      entity.setNotes(strNotes);

      calExecutor.saveEntities();
    }
    else if(evSource==btnViewAppointment) {
      int intSelIndex=lstAppointments.getSelectedIndex();
      if(intSelIndex==-1)
        return;

      AppointmentObject appointmentObj=(AppointmentObject)entity.getAppointments().elementAt(intSelIndex);

      calExecutor.appointmentViewerFrame.setAppointment(appointmentObj);

      calExecutor.appointmentViewerFrame.setVisible(true);
    }
    else if(evSource==btnAddAppointmentToMissed) {
      int intSelIndex=lstAppointments.getSelectedIndex();
      if(intSelIndex==-1)
        return;

      AppointmentObject appointmentObj=(AppointmentObject)entity.getAppointments().elementAt(intSelIndex);

      entity.getAppointmentsMissed().addElement(appointmentObj);

      lstAppointmentsMissed.add(appointmentObj.getDate().toString());

      calExecutor.saveEntities();
    }
    else if(evSource==btnRemoveAppointment) {
      int intSelIndex=lstAppointments.getSelectedIndex();
      if(intSelIndex==-1)
        return;

      entity.getAppointments().removeElementAt(intSelIndex);

      lstAppointments.remove(intSelIndex);

      calExecutor.saveEntities();
    }
    else if(evSource==btnViewAppointmentMissed) {
      int intSelIndex=lstAppointmentsMissed.getSelectedIndex();
      if(intSelIndex==-1)
        return;

      AppointmentObject appointmentObj=(AppointmentObject)entity.getAppointmentsMissed().elementAt(intSelIndex);

      calExecutor.appointmentViewerFrame.setAppointment(appointmentObj);

      calExecutor.appointmentViewerFrame.setVisible(true);
    }
    else if(evSource==btnRemoveAppointmentMissed) {
      int intSelIndex=lstAppointmentsMissed.getSelectedIndex();
      if(intSelIndex==-1)
        return;

      entity.getAppointmentsMissed().removeElementAt(intSelIndex);

      lstAppointmentsMissed.remove(intSelIndex);

      calExecutor.saveEntities();
    }
  }
}
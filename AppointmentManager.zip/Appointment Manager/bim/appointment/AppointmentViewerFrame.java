package bim.appointment;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Arrays;
import java.util.Date;

class AppointmentViewerFrame extends Frame
implements ActionListener {
  AppointmentViewerFrame refThis;
  CalendarExecutor calExecutor;
  AppointmentObject appointment;

  Label lblName=new Label("");

  Label lblAppointmentTime=new Label("");

  Label lblAppointmentDuration=new Label("");

  Label lblLocation=new Label("");

  TextArea txtNotes=new TextArea(5, 100);
  Button btnSetNotes=new Button("Set Notes");

  List lstEntities=new List(5);
  Button btnViewEntity=new Button("View Entity");

  AppointmentViewerFrame() {
    super();
    refThis=this;

    setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        refThis.setVisible(false);
      }
    });

    Panel tempPan=new Panel();
    tempPan.setLayout(new GridLayout(4, 1));
    Panel tempPanA=new Panel();
    tempPanA.setLayout(new BorderLayout());
    tempPanA.add("West", new Label("Name: "));
    tempPanA.add("Center", lblName);
    tempPan.add(tempPanA);
    Panel tempPanB=new Panel();
    tempPanB.setLayout(new BorderLayout());
    tempPanB.add("West", new Label("Appointment Time: "));
    tempPanB.add("Center", lblAppointmentTime);
    tempPan.add(tempPanB);
    Panel tempPanC=new Panel();
    tempPanC.setLayout(new BorderLayout());
    tempPanC.add("West", new Label("Appointment Duration: "));
    tempPanC.add("Center", lblAppointmentDuration);
    tempPan.add(tempPanC);
    Panel tempPanD=new Panel();
    tempPanD.setLayout(new BorderLayout());
    tempPanD.add("West", new Label("Location: "));
    tempPanD.add("Center", lblLocation);
    tempPan.add(tempPanD);

    add("North", tempPan);

    Panel tempPan2=new Panel();
    tempPan2.setLayout(new BorderLayout());
    tempPan2.add("North", new Label("Notes:"));
    tempPan2.add("Center", txtNotes);
    tempPan2.add("South", btnSetNotes);
    btnSetNotes.addActionListener(this);

    add("Center", tempPan2);

    Panel tempPan3=new Panel();
    tempPan3.setLayout(new BorderLayout());
    tempPan3.add("North", new Label("Entities:"));
    tempPan3.add("Center", lstEntities);
    tempPan3.add("South", btnViewEntity);
    btnViewEntity.addActionListener(this);

    add("South", tempPan3);
  }

  public void setCalendarExecutor(CalendarExecutor calExecutor) {
    this.calExecutor=calExecutor;
  }

  public void setAppointment(AppointmentObject appointment) {
    this.appointment=appointment;

    lblName.setText(appointment.getName());

    Date dateDate=appointment.getDate();
    lblAppointmentTime.setText(dateDate.toString());

    int intDurationHours=appointment.getDurationHours();
    int intDurationMinutes=appointment.getDurationMinutes();
    String strDurationMinutes=String.valueOf(intDurationMinutes);
    if(strDurationMinutes.length()==0)
      strDurationMinutes="00";
    else if(strDurationMinutes.length()==1)
      strDurationMinutes="0"+strDurationMinutes;
    lblAppointmentDuration.setText(String.valueOf(intDurationHours)+":"+strDurationMinutes);

    lblLocation.setText(appointment.getLocation());

    txtNotes.setText(appointment.getNotes());


    EntityObject entities[]=appointment.getEntities();

    String strEntities[]=new String[entities.length];
    for(int i=0;i<strEntities.length;i++)
      strEntities[i]=entities[i].getName();

    Arrays.sort(strEntities);

    lstEntities.removeAll();
    for(int i=0;i<strEntities.length;i++)
      lstEntities.add(strEntities[i]);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnSetNotes) {
      String strNotes=txtNotes.getText();

      appointment.setNotes(strNotes);

      calExecutor.saveCalendar();
    }
    else if(evSource==btnViewEntity) {
      int intSelIndex=lstEntities.getSelectedIndex();
      if(intSelIndex==-1)
        return;

      String strEntity=lstEntities.getItem(intSelIndex);

      EntityObject entityObj=(EntityObject)calExecutor.hashEntities.get(strEntity);

      if(entityObj==null) {
        MessageDialog mDialog=new MessageDialog(this, "Error. View Entity Dialog", "Entity couldn't be found.");
        mDialog.show();

        return;
      }
      else {
        calExecutor.entityViewerFrame.setEntity(entityObj);

        calExecutor.entityViewerFrame.setVisible(true);
      }
    }
  }
}
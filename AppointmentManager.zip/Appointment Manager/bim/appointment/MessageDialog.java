package bim.appointment;

import java.awt.*;
import java.awt.event.*;

class MessageDialog extends Dialog
implements ActionListener {
  Button btnOkay=new Button("Okay");

  MessageDialog(Frame parent, String strTitle, String strMessage) {
    super(parent, strTitle, true);

    add("Center", new Label(strMessage));

    Panel tempPan=new Panel();
    tempPan.add(btnOkay);
    btnOkay.addActionListener(this);
    add("South", tempPan);

    Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(screenDim.width/4, screenDim.height/4);
    setSize(screenDim.width/2, screenDim.height/2);
  }

  public void actionPerformed(ActionEvent ae) {
    dispose();
  }
}
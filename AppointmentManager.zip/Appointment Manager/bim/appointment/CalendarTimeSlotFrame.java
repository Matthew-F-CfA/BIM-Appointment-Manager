package bim.appointment;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Date;
import java.util.Vector;
import java.util.Hashtable;
import java.util.TreeMap;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Arrays;
import java.util.Map;
import java.util.Iterator;
import java.io.*;

class CalendarTimeSlotFrame extends Frame
implements ActionListener {
  CalendarTimeSlotFrame refThis;

  CalendarExecutor calExecutor;

  CalendarCanvas calCanvas=new CalendarCanvas();

  Menu menuOptions=new Menu("Options");
  Menu menuOptionsCalendar=new Menu("Calendar");
  MenuItem menuOptionsCalendarSetYear=new MenuItem("Set Year");
  MenuItem menuOptionsCalendarSetMonth=new MenuItem("Set Month");

  int intDurationHours=-1;
  int intDurationMinutes=-1;

  int intFromHour=-1;
  int intToHour=-1;

  Hashtable hashAvailableTimeSlots=new Hashtable();


  CalendarTimeSlotFrame() {
    super();
    refThis=this;

    setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        refThis.setVisible(false);
      }
    });

    add("Center", calCanvas);

    menuOptions.add(menuOptionsCalendar);
    menuOptionsCalendar.add(menuOptionsCalendarSetYear);
    menuOptionsCalendarSetYear.addActionListener(this);
    menuOptionsCalendar.add(menuOptionsCalendarSetMonth);
    menuOptionsCalendarSetMonth.addActionListener(this);

    MenuBar mBar=new MenuBar();
    mBar.add(menuOptions);

    setMenuBar(mBar);
  }

  public void setCalendarExecutor(CalendarExecutor calExecutor) {
    this.calExecutor=calExecutor;
  }

  public void set(int intDurationHours, int intDurationMinutes, int intFromHour, int intToHour) {
    this.intDurationHours=intDurationHours;
    this.intDurationMinutes=intDurationMinutes;

    this.intFromHour=intFromHour;
    this.intToHour=intToHour;


    int intDay=1;

    GregorianCalendar gCal=new GregorianCalendar(calCanvas.intCalendarYear, calCanvas.intCalendarMonth, intDay);

    TreeMap hashAppointments=calExecutor.calObj.getAppointments();

    hashAvailableTimeSlots.clear();

    Vector vecAppointments=(Vector)hashAppointments.get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, intDay));

    Vector vecAvailableTimeSlots=getAvailableTimeSlotsForDay(vecAppointments);

    hashAvailableTimeSlots.put(new Integer(intDay), vecAvailableTimeSlots);

    ++intDay;

    while(true) {
      vecAppointments=(Vector)hashAppointments.get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, intDay));

      vecAvailableTimeSlots=getAvailableTimeSlotsForDay(vecAppointments);

      hashAvailableTimeSlots.put(new Integer(intDay), vecAvailableTimeSlots);

      gCal.set(Calendar.DAY_OF_MONTH, intDay);

      if(gCal.get(Calendar.DAY_OF_MONTH)==1)
        break;

      ++intDay;
    }

    repaint();

//    calCanvas.initializeCanvas();
  }

  public Vector getAvailableTimeSlotsForDay(Vector vecAppointments) {
      if(vecAppointments==null)
        vecAppointments=new Vector();

      Vector vecAvailableTimeSlots=new Vector();

      int intCurrentHour=intFromHour;
      int intCurrentMinute=0;

      double dblCurrentHourMinutes=((double)intCurrentHour)+(((double)intCurrentMinute)/60.0d);

      double dblFromHour=(double)intFromHour;
      double dblToHour=(double)intToHour;

      double dblHourMinutes=0.0d;

      double dblDurationHours=(double)intDurationHours;
      double dblDurationMinutes=(double)intDurationMinutes;

      double dblDurationHourMinutes=dblDurationHours+dblDurationMinutes/60.0d;

      double dblDateHourMinutes=0.0d;

      int i=0;
      AppointmentObject nextAppointment=null;
      Date nextDate=null;
      for(;i<vecAppointments.size();i++) {
        nextAppointment=(AppointmentObject)vecAppointments.elementAt(i);
        nextDate=nextAppointment.getDate();
        dblDateHourMinutes=((double)nextDate.getHours())+(((double)nextDate.getMinutes())/60.0d);

        double dblDateDurationHourMinutes2=((double)nextAppointment.getDurationHours())+(((double)nextAppointment.getDurationMinutes())/60.0d);
            
        dblDateHourMinutes+=dblDateDurationHourMinutes2;

        if(dblDateHourMinutes>dblCurrentHourMinutes) {
          --i;
          break;
        }

/*
        if(nextDate.getHours()==intCurrentHour) {
          if(nextDate.getMinutes()>intCurrentMinute) {
            --i;
            break;
          }
        }
        else if(nextDate.getHours()>intCurrentHour) {
          --i;
          break;
        }
*/
      }

      double dblUntilHour=0.0d;

      if(i<vecAppointments.size()) {
//      if(i==-1) {
        nextAppointment=(AppointmentObject)vecAppointments.elementAt(i+1);
        nextDate=nextAppointment.getDate();
        dblDateHourMinutes=((double)nextDate.getHours())+(((double)nextDate.getMinutes())/60.0d);

        intCurrentMinute=intCurrentMinute/15*15;

        for(;intCurrentHour<24;intCurrentHour++) {
          boolean blnMustBreak=false;

//          intCurrentMinute=intCurrentMinute/15*15;
          for(;intCurrentMinute<60;intCurrentMinute+=15) {
            dblHourMinutes=(double)intCurrentHour;
            dblHourMinutes+=(((double)intCurrentMinute)/60.0d);
            dblUntilHour=dblHourMinutes+dblDurationHourMinutes;

            if(dblUntilHour<=dblDateHourMinutes) {
              if(dblUntilHour<=dblToHour)
                vecAvailableTimeSlots.addElement(new Double(dblHourMinutes));
              else {
                blnMustBreak=true;
                break;
              }
            }
            else {
              blnMustBreak=true;
              break;
            }
          }

          if(blnMustBreak)
            break;

          intCurrentMinute=0;
        }

        ++i;
      }

      if(dblUntilHour<dblToHour) {
        if(i==vecAppointments.size()) {
          dblDateHourMinutes=dblFromHour;
        }
/*
        if(i==vecAppointments.size()) {
          if(vecAppointments.size()==0) {
            dblDateHourMinutes=dblFromHour;
          }
          else {
            nextAppointment=(AppointmentObject)vecAppointments.elementAt(vecAppointments.size()-1);
            nextDate=nextAppointment.getDate();
            dblDateHourMinutes=((double)nextDate.getHours())+(((double)nextDate.getMinutes())/60.0d);

            double dblDateDurationHourMinutes2=((double)nextAppointment.getDurationHours())+(((double)nextAppointment.getDurationMinutes())/60.0d);
            
            dblDateHourMinutes+=dblDateDurationHourMinutes2;
          }
        }
*/
        else {
          nextAppointment=(AppointmentObject)vecAppointments.elementAt(i);
          nextDate=nextAppointment.getDate();
          dblDateHourMinutes=((double)nextDate.getHours())+(((double)nextDate.getMinutes())/60.0d);

//System.out.println("dblDateHourMinutes:0: "+dblDateHourMinutes);

          double dblDateDurationHourMinutes=((double)nextAppointment.getDurationHours())+(((double)nextAppointment.getDurationMinutes())/60.0d);

          dblDateHourMinutes+=dblDateDurationHourMinutes;

          double dblQuarters=dblDateHourMinutes%1.0d;
          dblDateHourMinutes=dblDateHourMinutes-dblQuarters;
          double dblQuarters0=dblQuarters%0.25d;

          if(dblQuarters0!=0.0d) {
            dblQuarters=dblQuarters-dblQuarters0;
            dblQuarters+=0.25d;
            if(dblQuarters==1.0d)
              dblDateHourMinutes+=1.0d;
            else
              dblDateHourMinutes+=dblQuarters;
          }
          else
            dblDateHourMinutes+=dblQuarters;

          ++i;

          if(i==vecAppointments.size()) {
//empty

//            double dblDateDurationHourMinutes2=((double)nextAppointment.getDurationHours())+(((double)nextAppointment.getDurationMinutes())/60.0d);
            
//            dblDateHourMinutes+=dblDateDurationHourMinutes2;

//System.out.println("dblDateHourMinutes:1: "+dblDateHourMinutes);
          }
          else {
            for(;i<vecAppointments.size();i++) {
              AppointmentObject nextAppointment2=(AppointmentObject)vecAppointments.elementAt(i);
              Date nextDate2=nextAppointment2.getDate();
              double dblDateHourMinutes2=((double)nextDate2.getHours())+(((double)nextDate2.getMinutes())/60.0d);
              double dblDateHourMinutes2b=dblDateHourMinutes2;

              double dblQuarters2=dblDateHourMinutes2%1.0d;
              dblDateHourMinutes2=dblDateHourMinutes2-dblQuarters2;
              double dblQuarters0b=dblQuarters2%0.25d;

              dblQuarters2=dblQuarters2-dblQuarters0b;
              dblDateHourMinutes2+=dblQuarters2;
//              if(dblQuarters0b!=0.0d)
//                dblDateHourMinutes+=0.25d;

//System.out.println("dblDateHourMinutes: "+dblDateHourMinutes);

              while(true) {
                double dblUntilHour2=dblDateHourMinutes+dblDurationHourMinutes;
                if(dblUntilHour2>dblDateHourMinutes2)
                  break;

                if(dblDateHourMinutes>=dblFromHour && dblUntilHour2<=dblToHour)
                  vecAvailableTimeSlots.addElement(new Double(dblDateHourMinutes));

                dblDateHourMinutes+=0.25d;
                if(dblDateHourMinutes==dblDateHourMinutes2)
                  break;
              }          

              nextAppointment=nextAppointment2;
              nextDate=nextDate2;
              dblDateHourMinutes=dblDateHourMinutes2b;

              double dblDateDurationHourMinutes2=((double)nextAppointment.getDurationHours())+(((double)nextAppointment.getDurationMinutes())/60.0d);

              dblDateHourMinutes+=dblDateDurationHourMinutes2;

              double dblQuarters3=dblDateHourMinutes%1.0d;
              dblDateHourMinutes=dblDateHourMinutes-dblQuarters3;
              double dblQuarters0c=dblQuarters3%0.25d;

              dblQuarters3=dblQuarters3-dblQuarters0c;
              dblDateHourMinutes+=dblQuarters3;
              if(dblQuarters0c!=0.0d)
                dblDateHourMinutes+=0.25d;
            }
          }
        }


        double dblQuarters=dblDateHourMinutes%1.0d;
        dblDateHourMinutes=dblDateHourMinutes-dblQuarters;
        double dblQuarters0=dblQuarters%0.25d;

        dblQuarters=dblQuarters-dblQuarters0;
        dblDateHourMinutes+=dblQuarters;
        if(dblQuarters0!=0.0d)
          dblDateHourMinutes+=0.25d;

        while(true) {
          double dblUntilHour2=dblDateHourMinutes+dblDurationHourMinutes;
          if(dblUntilHour2>dblToHour)
            break;

          if(dblDateHourMinutes>=dblFromHour && dblUntilHour2<=dblToHour)
            vecAvailableTimeSlots.addElement(new Double(dblDateHourMinutes));

          dblDateHourMinutes+=0.25d;
//          if(dblDateHourMinutes==dblDateHourMinutes2)
//            break;
        }

      }

      return vecAvailableTimeSlots;
  }







  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==menuOptionsCalendarSetYear) {
      TextInputDialog tDialog=new TextInputDialog(this, "Calendar Set Year Dialog", "Year:", "Set Year");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strInput=tDialog.getInput();

      if(strInput.length()!=4) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Set Year Dialog", "The year entered must be 4 digits long.");
        mDialog.show();

        return;
      }

      int intInput=-1;
      try {
        intInput=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Set Year Dialog", "The year entered must be an integer.");
        mDialog.show();

        return;
      }

      calCanvas.intCalendarYear=intInput;

      int intDay=1;

      GregorianCalendar gCal=new GregorianCalendar(calCanvas.intCalendarYear, calCanvas.intCalendarMonth, intDay);

      TreeMap hashAppointments=calExecutor.calObj.getAppointments();

      hashAvailableTimeSlots.clear();

      Vector vecAppointments=(Vector)hashAppointments.get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, intDay));

      Vector vecAvailableTimeSlots=getAvailableTimeSlotsForDay(vecAppointments);

      hashAvailableTimeSlots.put(new Integer(intDay), vecAvailableTimeSlots);

      ++intDay;

      while(true) {
        vecAppointments=(Vector)hashAppointments.get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, intDay));

        vecAvailableTimeSlots=getAvailableTimeSlotsForDay(vecAppointments);

        hashAvailableTimeSlots.put(new Integer(intDay), vecAvailableTimeSlots);

        gCal.set(Calendar.DAY_OF_MONTH, intDay);

        if(gCal.get(Calendar.DAY_OF_MONTH)==1)
          break;

        ++intDay;
      }

      calCanvas.repaint();
    }
    else if(evSource==menuOptionsCalendarSetMonth) {
      TextInputDialog tDialog=new TextInputDialog(this, "Calendar Set Month Dialog", "Month:", "Set Month");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strInput=tDialog.getInput();

      int intInput=-1;

      if(strInput.equals("January"))
        intInput=0;
      else if(strInput.equals("February"))
        intInput=1;
      else if(strInput.equals("March"))
        intInput=2;
      else if(strInput.equals("April"))
        intInput=3;
      else if(strInput.equals("May"))
        intInput=4;
      else if(strInput.equals("June"))
        intInput=5;
      else if(strInput.equals("July"))
        intInput=6;
      else if(strInput.equals("August"))
        intInput=7;
      else if(strInput.equals("September"))
        intInput=8;
      else if(strInput.equals("October"))
        intInput=9;
      else if(strInput.equals("November"))
        intInput=10;
      else if(strInput.equals("December"))
        intInput=11;
      else {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Set Month Dialog", "The month entered was not recognized.");
        mDialog.show();

        return;
      }

      calCanvas.intCalendarMonth=intInput;

      int intDay=1;

      GregorianCalendar gCal=new GregorianCalendar(calCanvas.intCalendarYear, calCanvas.intCalendarMonth, intDay);

      TreeMap hashAppointments=calExecutor.calObj.getAppointments();

      hashAvailableTimeSlots.clear();

      Vector vecAppointments=(Vector)hashAppointments.get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, intDay));

      Vector vecAvailableTimeSlots=getAvailableTimeSlotsForDay(vecAppointments);

      hashAvailableTimeSlots.put(new Integer(intDay), vecAvailableTimeSlots);

      ++intDay;

      while(true) {
        vecAppointments=(Vector)hashAppointments.get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, intDay));

        vecAvailableTimeSlots=getAvailableTimeSlotsForDay(vecAppointments);

        hashAvailableTimeSlots.put(new Integer(intDay), vecAvailableTimeSlots);

        gCal.set(Calendar.DAY_OF_MONTH, intDay);

        if(gCal.get(Calendar.DAY_OF_MONTH)==1)
          break;

        ++intDay;
      }

      calCanvas.repaint();
    }
  }

  class CalendarCanvas extends Canvas
  implements MouseListener {
    String strCalendarMonth[]={"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    String strWeekDays[]={"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

    int intDayWidth=-1;
    int intDayHeight=-1;

    int intCalendarYear=-1;
    int intCalendarMonth=-1;

    int intCharHeight=-1;

//    int intSelectedDay=1;

    CalendarCanvas() {
      super();

      addMouseListener(this);
    }

    public void initializeCanvas() {
      Date dateNow=new Date();
      intCalendarYear=dateNow.getYear()+1900;
      intCalendarMonth=dateNow.getMonth();

/*
      int intDay=1;

      GregorianCalendar gCal=new GregorianCalendar(calCanvas.intCalendarYear, calCanvas.intCalendarMonth, intDay);

      TreeMap hashAppointments=calExecutor.calObj.getAppointments();

      hashAvailableTimeSlots.clear();

      Vector vecAppointments=(Vector)hashAppointments.get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, intDay));

      Vector vecAvailableTimeSlots=getAvailableTimeSlotsForDay(vecAppointments);

      hashAvailableTimeSlots.put(new Integer(intDay), vecAvailableTimeSlots);

      ++intDay;

      while(true) {
        vecAppointments=(Vector)hashAppointments.get(new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, intDay));

        vecAvailableTimeSlots=getAvailableTimeSlotsForDay(vecAppointments);

        hashAvailableTimeSlots.put(new Integer(intDay), vecAvailableTimeSlots);

        gCal.set(Calendar.DAY_OF_MONTH, intDay);

        if(gCal.get(Calendar.DAY_OF_MONTH)==1)
          break;

        ++intDay;
      }

      repaint();
*/
    }

    public void initializeCanvas2() {
      Dimension canvasDim=getSize();

      int intHeight=canvasDim.height;
      intHeight-=(intCharHeight*2+10);

      intDayWidth=canvasDim.width/7;
      intDayHeight=intHeight/6;
    }

    public void mouseEntered(MouseEvent me) {
    }

    public void mouseExited(MouseEvent me) {
    }

    public void mousePressed(MouseEvent me) {
    }

    public void mouseReleased(MouseEvent me) {
    }

    public void mouseClicked(MouseEvent me) {
      Point mePoint=me.getPoint();

      int meX=mePoint.x;
      int meY=mePoint.y;

      meY-=(intCharHeight*2+10);

      int intSelectedX=meX/intDayWidth;
      int intSelectedY=meY/intDayHeight;

      GregorianCalendar gCal=new GregorianCalendar(intCalendarYear, intCalendarMonth, 1);

      int intDayOfWeek=gCal.get(Calendar.DAY_OF_WEEK);
      --intDayOfWeek;
//0 is sunday and 6 is saturday

      int intDay=1;

      int intSelectedDay=-1;

      for(int i=intDayOfWeek;i<7;i++) {
        if(intSelectedY==0 && i==intSelectedX) {
          intSelectedDay=intDay;
//          repaint();
          break;
        }

        ++intDay;
      }

      if(intSelectedDay==-1) {

        int intNextY=1;


        while(true) {
          for(int i=0;i<7;i++) {
            if(intSelectedY==intNextY && intSelectedX==i) {
              intSelectedDay=intDay;
//              repaint();
              break;
            }

            ++intDay;

            gCal.set(Calendar.DAY_OF_MONTH, intDay);

            if(gCal.get(Calendar.DAY_OF_MONTH)==1) {
              return;
            }
          }

          if(intSelectedDay!=-1)
            break;

          ++intNextY;
        }      
      }

      Vector vecTimeSlots=(Vector)hashAvailableTimeSlots.get(new Integer(intSelectedDay));

      Vector vecIntTimeSlots=new Vector();

//      String strTimeSlots[]=new String[vecTimeSlots.size()];

      List lstList=new List(5);

      for(int i=0;i<vecTimeSlots.size();i++) {
        double dblNextTime=((Double)vecTimeSlots.elementAt(i)).doubleValue();

        double dblNextTimeMinutes=dblNextTime%1.0d;
        double dblNextTimeHours=dblNextTime-dblNextTimeMinutes;
        dblNextTimeMinutes*=60.0d;

        int intNextTimeHours=(int)dblNextTimeHours;
        int intNextTimeMinutes=(int)Math.floor(dblNextTimeMinutes);

        int intNextTime[]={intNextTimeHours, intNextTimeMinutes};

        vecIntTimeSlots.addElement(intNextTime);

        String strNextTimeHours=String.valueOf(intNextTimeHours);
        String strNextTimeMinutes=String.valueOf(intNextTimeMinutes);
        if(strNextTimeMinutes.length()==1)
          strNextTimeMinutes="0"+strNextTimeMinutes;

//        strTimeSlots[i]=strNextTimeHours+":"+strNextTimeMinutes;

        lstList.add(strNextTimeHours+":"+strNextTimeMinutes);
      }

      ListDialog lDialog=new ListDialog(refThis, "Calendar Available Time Slots Dialog", lstList);
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      int intSelIndex=lstList.getSelectedIndex();

      int intSelectedTime[]=(int[])vecIntTimeSlots.elementAt(intSelIndex);


      int intNextTimeHours=intSelectedTime[0];
      int intNextTimeMinutes=intSelectedTime[1];

      calExecutor.scheduleAppointment(intCalendarYear, intCalendarMonth, intSelectedDay, intNextTimeHours, intNextTimeMinutes, intDurationHours, intDurationMinutes);

      refThis.setVisible(false);
    }

    public void paint(Graphics graph) {
      if(intCalendarMonth==-1)
        return;

      if(intCharHeight==-1) {
        FontMetrics fMetr=graph.getFontMetrics();
        intCharHeight=fMetr.getHeight();

        initializeCanvas2();
      }

      graph.drawString(String.valueOf(intCalendarYear)+" : "+strCalendarMonth[intCalendarMonth], 5, intCharHeight+5);

      int intXPosition=0;

      for(int i=0;i<7;i++) {
        graph.drawString(strWeekDays[i], intXPosition, intCharHeight+5+intCharHeight+5);

        intXPosition+=intDayWidth;
      }

      for(int i=0;i<=7;i++) {
        graph.drawLine(i*intDayWidth, intCharHeight*2+10, i*intDayWidth, getSize().height);
      }

      graph.drawLine(0, 0, getSize().width, 0);

      graph.drawLine(0, intCharHeight+5, getSize().width, intCharHeight+5);

      for(int i=0;i<=6;i++) {
        graph.drawLine(0, i*intDayHeight+intCharHeight*2+10, getSize().width, i*intDayHeight+intCharHeight*2+10);
      }

      GregorianCalendar gCal=new GregorianCalendar(intCalendarYear, intCalendarMonth, 1);

      int intDayOfWeek=gCal.get(Calendar.DAY_OF_WEEK);
      --intDayOfWeek;
//0 is sunday and 6 is saturday

      intXPosition=intDayOfWeek*intDayWidth;

      int intDay=1;

      for(int i=intDayOfWeek;i<7;i++) {
        if(((Vector)hashAvailableTimeSlots.get(new Integer(intDay))).size()>0) {
          graph.setColor(Color.blue);
          graph.fillRect(intXPosition, intCharHeight*2+10, intDayWidth, intDayHeight);
          graph.setColor(Color.black);
        }
/*
        if(intSelectedDay==intDay) {
          graph.setColor(Color.green);
          graph.fillRect(intXPosition, intCharHeight*2+10, intDayWidth, intDayHeight);
          graph.setColor(Color.black);
        }
        else {
          Vector vecAppointments=(Vector)calObj.getAppointments().get(new Date(intCalendarYear-1900, intCalendarMonth, intDay));
          if(vecAppointments!=null) {
            if(vecAppointments.size()>0) {
              graph.setColor(Color.red);
              graph.fillRect(intXPosition, intCharHeight*2+10, intDayWidth, intDayHeight);
              graph.setColor(Color.black);
            }
          }
        }
*/

        graph.drawString(String.valueOf(intDay), intXPosition+5, intCharHeight+5+intCharHeight+5+intCharHeight+5);

        ++intDay;

        intXPosition+=intDayWidth;
      }

      int intYPosition=intCharHeight+5+intCharHeight+5;
      intYPosition+=intDayHeight;

      while(true) {
        intXPosition=0;

        boolean blnMustBreak=false;
        for(int i=0;i<7;i++) {
          if(((Vector)hashAvailableTimeSlots.get(new Integer(intDay))).size()>0) {
            graph.setColor(Color.blue);
            graph.fillRect(intXPosition, intYPosition, intDayWidth, intDayHeight);
            graph.setColor(Color.black);
          }
/*
          if(intSelectedDay==intDay) {
            graph.setColor(Color.green);
            graph.fillRect(intXPosition, intYPosition, intDayWidth, intDayHeight);
            graph.setColor(Color.black);
          }
          else {
            Vector vecAppointments=(Vector)calObj.getAppointments().get(new Date(intCalendarYear-1900, intCalendarMonth, intDay));
            if(vecAppointments!=null) {
              if(vecAppointments.size()>0) {
                graph.setColor(Color.red);
                graph.fillRect(intXPosition, intYPosition, intDayWidth, intDayHeight);
                graph.setColor(Color.black);
              }
            }
          }
*/

          graph.drawString(String.valueOf(intDay), intXPosition+5, intYPosition+intCharHeight+5);

          ++intDay;

          intXPosition+=intDayWidth;

          gCal.set(Calendar.DAY_OF_MONTH, intDay);

          if(gCal.get(Calendar.DAY_OF_MONTH)==1) {
            blnMustBreak=true;
            break;
          }
        }

        if(blnMustBreak)
          break;

        intYPosition+=intDayHeight;
      }
    }
  }
}
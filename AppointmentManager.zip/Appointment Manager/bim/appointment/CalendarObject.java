package bim.appointment;

import java.io.Serializable;
import java.util.TreeMap;

class CalendarObject
implements Serializable {
  TreeMap hashAppointments=new TreeMap(); //Keys are Dates with year, month, day and Values are Vector containing all of the AppointmentObjects for that day

  CalendarObject() {
  }

  public TreeMap getAppointments() {
    return hashAppointments;
  }

  public void setAppointments(TreeMap hashAppointments) {
    this.hashAppointments=hashAppointments;
  }
}